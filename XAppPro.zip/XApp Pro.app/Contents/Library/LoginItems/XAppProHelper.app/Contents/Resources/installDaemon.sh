#!/bin/sh

echo "开始安装守护进程"
if [[ -a Library/LaunchDaemons/cn.better365.XApp.helper.plist ]]
#检查plist文件是否存在 如果存在则先删除和卸载旧的守护进程
then
#移除旧的守护进程配置文件
sudo launchctl unload /Library/LaunchDaemons/cn.better365.XApp.plist
sudo rm -f /Library/LaunchDaemons/cn.better365.XApp.helper.plist

fi
#先创建守护进程程序的存放目录 /Library/Application\ Support/Better365/Uninstall
sudo mkdir -p /Library/Application\ Support/Better365/Uninstall
#将本地的守护进程程序拷贝到新创建的目录中去
sudo cp $HOME/Desktop/cleanUpDaemon/uninstallHelper /Library/Application\ Support/Better365/Uninstall

#拷贝守护进程配置文件到守护进程目录
sudo cp $HOME/Desktop/cleanUpDaemon/cn.better365.XApp.helper.plist /Library/LaunchDaemons
#添加守护进程配置文件的拥有者权限和执行权限
sudo chown root:wheel /Library/LaunchDaemons/cn.better365.XApp.helper.plist
sudo sudo chmod 644 /Library/LaunchDaemons/cn.better365.XApp.helper.plist
#启动守护进程
sudo launchctl load -w /Library/LaunchDaemons/cn.better365.XApp.helper.plist

